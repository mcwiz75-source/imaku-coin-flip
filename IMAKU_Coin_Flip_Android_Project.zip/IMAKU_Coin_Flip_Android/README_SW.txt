IMAKU COIN FLIP ANALYZER - ANDROID PROJECT

Hii ni project ya Android Studio inayofungua programu ya analyzer ndani ya Android WebView.
Si APK iliyokwisha-build. Ili kupata APK:
1. Fungua folder hii kwa Android Studio kwenye Windows.
2. Ruhusu Gradle Sync ikamilike.
3. Chagua Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK itapatikana: app/build/outputs/apk/debug/app-debug.apk
5. Hamisha APK kwenye simu na uisakinishe. Ruhusu 'Install unknown apps' kwa chanzo unachotumia ikiwa Android itaomba.

Mahitaji: Android Studio ya kisasa, JDK inayokuja nayo, na Android SDK Platform 35.
Programu inafanya uchambuzi wa kihesabu na hash zilizowekwa; haitabiri kwa uhakika matokeo ya mchezo wa random.
